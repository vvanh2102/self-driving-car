#!/bin/bash
source /opt/ros/eloquent/setup.sh
colcon build --symlink-install


















